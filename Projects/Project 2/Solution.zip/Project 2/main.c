#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include "queue.h"
#include <pthread.h>
#include <semaphore.h>
#include "argument.h"

int question_count;
int commentator_count;
int responses;
float answer_probabilty;
float speaking_time;

struct IntQueue q;
pthread_cond_t* conditional_var_ptr;
sem_t queue_mutex, moderator_mutex, commentator_response_mutex, breaking_news_mutex, *commentator_answer_mutex;
struct timeval start, current;
bool terminal = true;
int status;

int pthread_sleep(double seconds)
{
    pthread_mutex_t mutex;
    pthread_cond_t conditionvar;
    if (pthread_mutex_init(&mutex, NULL))
    {
        return -1;
    }
    if (pthread_cond_init(&conditionvar, NULL))
    {
        return -1;
    }

    conditional_var_ptr = &conditionvar;

    struct timeval tp;
    struct timespec timetoexpire;
    // When to expire is an absolute time, so get the current time and add
    // it to our delay time
    gettimeofday(&tp, NULL);
    long new_nsec = tp.tv_usec * 1000 + (seconds - (long)seconds) * 1e9;
    timetoexpire.tv_sec = tp.tv_sec + (long)seconds + (new_nsec / (long)1e9);
    timetoexpire.tv_nsec = new_nsec % (long)1e9;

    pthread_mutex_lock(&mutex);
    int res = pthread_cond_timedwait(&conditionvar, &mutex, &timetoexpire);
    pthread_mutex_unlock(&mutex);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&conditionvar);

    // Upon successful completion, a value of zero shall be returned
    return res;
}

void printTime()
{
    gettimeofday(&current, NULL);

    int diff = (current.tv_sec * 1000000 + current.tv_usec) -
    (start.tv_sec * 1000000 + start.tv_usec);

    diff /= 1000;

    int m = diff / 60000;
    float s = diff % 60000;

    s /= 1000.0;

    printf("[");
    if (m < 10)
        printf("0");

    printf("%d", m);

    printf(":");
    if (s < 10)
        printf("0");

    printf("%.3f] ", s);
}

void *moderator(void *arg)
{
    int comID;
    gettimeofday(&start, NULL);

    for (int i = 0; i < question_count; ++i)
    {
        responses = 0;
        // asked a question

        printTime();

        printf("Moderator asks question %d\n", i + 1);

        sem_post(&commentator_response_mutex);

        for (int i = 0; i < commentator_count; ++i)
            sem_wait(&moderator_mutex);

        while (!isEmpty(&q))
        {
            comID = front(&q);
            pop(&q);

            sem_post(commentator_answer_mutex + comID);
            sem_wait(&moderator_mutex);
        }
    }
    terminal = false;
    pthread_exit(NULL);
}

void *commentator(void *arg)
{
    int id = *((int *)arg);
    free(arg);

    bool flag;
    double random;
    

    for (int i = 0; i < question_count; ++i)
    {
        sem_wait(&commentator_response_mutex);

        flag = true;
        random = (double)rand() / RAND_MAX;

        if (random < answer_probabilty)
        {
            //sem_wait(&queue_mutex);
            printTime();
            printf("Commentator #%d generates answer, position in queue %d\n", id, q.size);
            push(&q, id);
            //sem_post(&queue_mutex);
            flag = false;
        }

        if (++responses < commentator_count)
            sem_post(&commentator_response_mutex);
        sem_post(&moderator_mutex);
        if (flag)
        {
            pthread_sleep(0.001);
            continue;
        }

        sem_wait(commentator_answer_mutex + id);
        random = (double)rand() / RAND_MAX;
        float ti = random * speaking_time;
        printTime();
        printf("Commentator #%d's turn to speak for %.3f seconds\n", id, ti);
        status = 1;
        pthread_sleep(ti);
        if (status == 1) 
        {
            printTime();
            printf("Commentator #%d finished speaking\n", id);
            sem_post(&moderator_mutex);
        }
        else if (status == 0)
        {
            printTime();
            printf("Commentator #%d is cut short due to a breaking news\n", id);
        }
    }

    pthread_exit(NULL);
}

void* breaking_news(void* arg)
{
    while (true)
    {
        sem_wait(&breaking_news_mutex);
        status = 0;
        pthread_cond_signal(conditional_var_ptr);

        printTime();

        printf("Breaking news!\n");

        pthread_sleep(5);

        printTime();

        printf("Breaking news ends\n");

        sem_post(&moderator_mutex);    
    }
    pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
    struct argp_option options[] = {
        {"commentators", 'n', "INT", 0, "Number of commentators", 0},
        {"questions", 'q', "INT", 0, "Number of questions", 0},
        {"rpob_to_answer", 'p', "FLOAT (0-1)", 0, "Probability to answer", 0},
        {"speaking_time", 't', "INT", 0, "Time range to speak", 0},
        {"prob_of_news", 'b', "FLOAT (0-1)", 0, "Probability of breaking news", 0},
        {"seed_for_RNG", 's', "INT", 0, "Seed for random function", 0},
        {0, 0, 0, 0, 0, 0}};

    struct argp argp = {options, parse_opt, 0, 0, 0, 0, 0};

    struct arguments arguments;
    arguments.commentators = 0;
    arguments.answer_probabilty = 0.0;
    arguments.questions = 0;
    arguments.speaking_time = 0;
    arguments.breaking_news_probability = 0.0;

    argp_parse(&argp, argc, argv, 0, 0, &arguments);

    commentator_count = arguments.commentators;
    question_count = arguments.questions;
    answer_probabilty = arguments.answer_probabilty;
    speaking_time = arguments.speaking_time;

    srand(arguments.seed);

    pthread_t moderatorTID, breaking_newsTID;
    pthread_t *commentatorTID = malloc(commentator_count* sizeof(pthread_t));
    commentator_answer_mutex = malloc(commentator_count* sizeof(sem_t));

    sem_init(&queue_mutex, 0, 1);
    sem_init(&moderator_mutex, 0, 0);
    sem_init(&commentator_response_mutex, 0, 0);
    sem_init(&breaking_news_mutex, 0, 0);
    initQueue(&q);

    for (int i = 0; i < commentator_count; ++i)
        sem_init(commentator_answer_mutex + i, 0, 0);

    pthread_create(&moderatorTID, NULL, &moderator, NULL);
    int* ptr;
    for (int i = 0; i < commentator_count; ++i)
    {
        ptr = malloc(sizeof(int));
        *ptr = i;
        pthread_create(commentatorTID + i, NULL, &commentator, ptr);
    }

    pthread_create(&breaking_newsTID, NULL, &breaking_news, NULL);


    double random;
    while (terminal)
    {
        pthread_sleep(1);
        random = (double)rand() / RAND_MAX;

        if (random < arguments.breaking_news_probability)
            sem_post(&breaking_news_mutex);
    }

    pthread_join(moderatorTID, NULL);

    for (int i = 0; i < commentator_count; ++i)
        pthread_join(commentatorTID[i], NULL);

    pthread_cancel(breaking_newsTID);

    sem_destroy(&queue_mutex);
    sem_destroy(&moderator_mutex);
    sem_destroy(&commentator_response_mutex);
    sem_destroy(&breaking_news_mutex);

    for (int i = 0; i < commentator_count; ++i)
        sem_destroy(commentator_answer_mutex + i);

    free(commentatorTID);
    free(commentator_answer_mutex);
    return 0;
}
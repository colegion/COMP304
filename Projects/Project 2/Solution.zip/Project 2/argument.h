#include <argp.h>

struct arguments
{
    int commentators;
    int questions;
    float answer_probabilty;
    int speaking_time;
    float breaking_news_probability;
    int seed;
};

static int parse_opt(int key, char *arg, struct argp_state *state)
{
    struct arguments *arguments = (struct arguments*) state->input;
    switch (key)
    {
    case 'n':
        arguments->commentators = strtol(arg, NULL, 10);
        break;
    case 'q':
        arguments->questions = strtol(arg, NULL, 10);
        break;
    case 't':
        arguments->speaking_time = strtof(arg, NULL);
        break;
    case 'p':
        arguments->answer_probabilty = strtof(arg, NULL);
        break;
    case 'b':
        arguments->breaking_news_probability = strtof(arg, NULL);
        break;
    case 's':
        arguments->seed = strtol(arg, NULL, 10);
        break;
    case ARGP_KEY_FINI:
        if (arguments->commentators < 1
         || arguments->questions < 1 
         || arguments->speaking_time < 1 
         || (arguments->answer_probabilty < 0 && arguments->answer_probabilty > 1) 
         || (arguments->breaking_news_probability < 0 && arguments->breaking_news_probability > 1))
        {
            argp_error(state, "missing arguments\n");
        }
        break;
    default:
        return ARGP_ERR_UNKNOWN;
    }

    return 0;
}
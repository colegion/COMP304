#include<stdlib.h>

struct IntQueueNode
{
    int val;
    struct IntQueueNode *next;
};

struct IntQueue
{
    struct IntQueueNode *front;
    struct IntQueueNode *back;
    int size;
};

void initQueue(struct IntQueue* queue)
{
    queue->front = NULL;
    queue->back = NULL;
    queue->size = 0;
}

void push(struct IntQueue *queue, int val)
{
    ++queue->size;
    struct IntQueueNode* temp = (struct IntQueueNode*) malloc(sizeof(struct IntQueueNode));
    temp->val = val;
    temp->next = NULL;

    if (queue->back == NULL)
    {
        queue->front = queue->back = temp;
        return;
    }

    queue->back->next = temp;
    queue->back = temp;
}

void pop(struct IntQueue* queue)
{
    if (queue->front != NULL)
    {
        struct IntQueueNode* temp = queue->front;
        queue->front = queue->front->next;

        if (queue->front == NULL)
            queue->back = NULL;

        free(temp);
        --queue->size;
    }
}

int front(struct IntQueue* queue)
{
    return queue->front->val;
}

bool isEmpty(struct IntQueue* queue)
{
    return queue->size == 0;
}

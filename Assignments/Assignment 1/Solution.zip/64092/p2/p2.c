#include<stdio.h> 
#include<stdlib.h> 
#include<unistd.h> 
#include<string.h> 
#include<sys/wait.h> 
#include<time.h>

int main(void){

    time_t t;
    time(&t);
    int fd1[2];
    int fd2[2];

    int pid = fork();

    if(pid < 0){
        fprintf(stderr, "fork failed");
        return 1;
    }

    else if(pid > 0){
        close(fd1[0]);

        write(fd1[1], &t, 0);
        close(fd1[1]);

        wait(NULL);

        printf("Current Time: %s", ctime(&t));
        kill(pid, SIGKILL);
        exit(0);
    }
    else {
        read(fd1[0], &t, 0);
        printf("Current Time: %s", ctime(&t));
        sleep(3);
        int nPid = fork();

        if(nPid > 0){
            close(fd2[0]);
            write(fd2[1], &t, 0);
            close(fd2[1]);

            wait(NULL);

            printf("Current Time: %s", ctime(&t));
            kill(nPid, SIGKILL);
            sleep(3);
        }
        else if(nPid == 0){
            read(fd2[0], &t, 0);
            printf("Current Time: %s", ctime(&t));
            sleep(3);
        }
    }
    return 0;
}
#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h>

int main(void){
    
    int level = 0;

    printf("Base Process ID: %d , Level: %d\n", getpid(), level);

    for(int i = 0; i < 4; i++){
        int pid = fork();
        level++;

        if(pid == 0){
            printf("Child Process ID: %d, Parent Id: %d, Level: %d\n",
            getpid(), getppid(), level);
        }
    }

    return 0;
}
#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <wait.h>

int main(void){

    int pid = fork();

    if(pid == 0){
        execlp("/bin/ps", "-f", NULL);
    }else{
        wait(NULL);
        printf("Child finished execution.");
    }
    return 0;
}
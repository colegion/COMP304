#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main(void){

    int pid = fork();

    if(pid == 0){
        exit(0);
    }

    sleep(5);
}
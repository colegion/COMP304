I basically compiled my files by using traditional gcc command: gcc -o -p1a -p1a.c (for example) 
To run the code, I again used a traditional way in terminal: ./p1a, example.
